--- Introduction ---

The original purpose of this program was to give us the ability to watch accounts for new videos without revealing to the rest of the world that we are doing so. The best stuff happens when the girls are not even aware of pedos, while the ones trying to groom the girls almost always only manage to scare the girls away. Those people usually only show up in the aftermath of someone letting the whole world know that the girls are being useful to pedos. It follows then that pedos should keep the list of girls being useful to them completely secret.

However in time methods were innovated to drastically improve the efficiency of video sorting. All "jailbait" sites were not able to keep up with my technology, and they became useless to me. I already knew about almost all of the useful girls on the sites and their methods of posting were incredibly inefficient. They also often pose too much of a risk with illegal material and have rules designed to keep me out.

Important - War Room cannot handle /channel/'s, only /user/'s. It will have an infinite loop of 400 errors if any /channel/ accounts are in your list. You'll have to bookmark them for now, they only make up a small fraction of accounts so I'm not too concerned about it.

--- How to run this program ---
You will need to install the Java Runtime Environment (JRE) from the http://java.sun.com, but preferably the JDK.

1. Load the source file in JCreator 3.5.013
2. Press the "run" button
Or:
1. Double-click the run.bat batch file.

Although it is now easier to run my program without being properly computer literate, jobs and women should still be apportioned in direct correlation with a man's honesty and ability to do things independently. Non-victimizing pedophilia is the epitome of both. Users of non-Windows OS's will have to figure out some other way to get Java to run WarRoom.class

--- Preparing this program for use ---

First you will need to obtain a subscriptions list for the program to scan. This program used to have the ability to dump all of the subscriptions from a Youtube account, but they change things all of the time. It did work in 2011 and evacuated the 600 or so accounts from my old channel.

You will have to manually copy all of the subscriptions to a text file. However closing your account won't do any good. You will still show up on the girls' subscribers and all your other activity will still be there. Even if you unsubscribe one by one the girls will all be asking why. They take unsubscribing as an insult. The damage has already been done. Just private everything on the account and don't use it anymore.

--- List of file names ---

readme.txt - This file, instructions to use the program

(month)##.txt, e.g. may9.txt - A list of accounts along with the month and day they were last scanned. This used to be in a huge master.txt but resulted in large inefficiencies once the scan period became 40+ days. You must review the videos made since the prior scan, and if scans cover 40 days while it's been 40 days since the last scan that means you must search 80 days at the end. It's better if the scan is sorted as quickly as possible, so list sizes of around 500 accounts are recommended. I currently have close to 10,000 accounts split up into these lists.

results-(month1)##-(month2)##.txt, e.g. results-oct20-jul20.txt - Results of scanning new videos. The first monthly figure is the day they are scanned, and the second monthly figure is the prior day they were scanned, so you know how far back to look for videos.

I also had a method to keep track of which accounts have zero videos but it's too chaotic now, talked about later.

Feel free to use whatever file names you want. However these names are used for the purpose of instruction in the following section. Note however as a means of convenience the (month)##.txt files should be kept in a "dates" subfolder.

--- Scanning accounts for new videos ---

The file name you want to scan is the one that it's been the longest since you scanned it. The number of days to scan is the amount of calendar days it has been since you scanned that. I don't know whether the time zone expressed in the feeds is California time or translated to local time, but I live close enough to there and don't scan in the 9 pm - 3 am range. If pedos do not know about the girls there is very little risk of videos/accounts being removed so you don't usually need to get stuff within minutes of it coming out. Optimally the search period should be about 30 days. My girls make hundreds of videos a day so that is too bandwidth intensive anyway to download them all in 720p. The results should be saved to results-(month1)##-(month2)##.txt . Any new girls you want to track should be added to the account list file for today, e.g. if today is October 20 then add them to oct20.txt .

After a few minutes depending on the amount of accounts you will have a finished results file. Cut 5 accounts from the new video accounts into the Multiple URL Opener, then send those accounts to ByTubeD to download everything since the last scan in 240p. Save each scan to a folder named after the Youtube account with an " m" after that. The following steps apply to determine how to handle these folders:

0. I have a "Youtube Progress" folder with "1 - Incoming", "2 - Cleared", "3 - Thumbnails", "4 - Quality", and "5 - Review" in it. When the downloads are completed the "m" folders are dragged here.

1. The Incoming folder is where the "m" folders are put to sort about 150 files worth at a time. First delete all the .txt and .htm files ByTubeD leaves behind. Then use the command "mtn -c 5 -s 10 -w 3000" on folder 1. I've included a batch file for that, but you'll have to move Movie Thumbnailer (mtn) to C:\Program Files\mtn-200808a-win32 , or to another location and modify the batch file. After mtn is done, cut all the "_s.jpg" files and paste them in folder 3.

2. The Cleared folder is where the "m" folders are placed once the thumbnails are moved to folder 3.

3. The Thumbnails folder is where the thumbnails go. Once these are obtained, scan through them with IrfanView, deleting those that are clearly not win. Once there are only possible wins left, go back to folder 2 and look through the "m" folders one at a time, deleting anything without a matching thumbnail then previewing what's left. If the videos are not worth downloading then delete them and the corresponding thumbnail. At the end there should be the 240p videos with matching thumbnails, which are what you are going to want to get from Youtube from the greater of 720p or best quality available.

4. The Quality section is pretty much just "m" folders from folder 2 that I have delayed downloading.

5. The Review section is downloaded high-quality videos that have yet to be decided whether to be kept.

There's also means for keeping which accounts went from some to no videos (and vice versa) but it's too chaotic now. Formerly the results would be renamed to oldresults.txt on every scan and that would be compared with the zero video accounts on the new results.txt . This is the list of girls that have quit (or got hacked :/ ) and the ones that have come back from the dead. From experience the ratio of raised dead to dying is around 2:5. This is key if you want to try to find girls or bring them back after their account is closed or they delete all their videos. You can always put the zero-video lists in the "Zero" subfolder in "dates" and figure it out yourself...

--- Other notes ---

- If a girl's video title sounds important (i.e. "I'm quitting") you should listen.

- QuickJava is handy for a variety of reasons. The primary usefulness is being able to easily disable Java or Flash. Having the Add-on Bar for Firefox is a necessity, you'll need the Classic Theme Restorer.

- If you hold control and use the mouse wheel you can zoom in to get a better look at the thumbnails.

- DownloadHelper is an option for downloading the videos, but is becoming obsolete. 720p is the best compromise of video quality, size and cpu usage. Clipconverter.cc (ugh, ads) is another option, and you often need it because DownloadHelper doesn't always work, even downloading 0 byte files in many cases. It should be noted that your Recycle Bin will have a "trail" to find out where these zero-byte videos came from, so you shouldn't empty it until you're finished.

- The Multiple URLs Opener will not work properly with Torbutton unless you disable "Block Non-Tor access to network from file:// urls". Not that I've even used Tor much since like 2009.

- Before add any accounts search the Dates folder for anything containing that text. Maybe later I'll provide a method for finding duplicates across files.

- I wouldn't recommend talking to the girls at all unless they are being ruined by asshats. The weapons at your disposal are to ask that they make backup/off-site accounts (as a defense against flagging), that they don't get naked or give out personal info (for their safety) and friends only their video comments, channel comments and PMs (when they are being harassed). But if they only talked to other kids their age we would rarely have to use these weapons.

- Feel free to get those fucktards that make sexual and fetish comments and requests to 12 year olds v&. They are the root cause of why we can't have nice things. This does not apply of course to skilled professionals that do not scare the girls away or invite antis or newfags that do. I am neutral towards this aspect of our culture.

- Don't view videos with an account. It will modify similar videos and recommendations based on your actions. As a result it will be girls you looked at in the past everyone knows about. It may also lead to people finding the girls you like. Girls seek each other out and they provide the best scouts for us.

- It is your judgement call on when it is time to share the videos. Sharing marks the girls as useful and invites idiots to groom the girls. A bad time is when they are ten years old and are recently very active. A good time is when they are sixteen years old. Either way you should edit out any references to the account name in the video and change the file name. And sharing the original video urls is pretty stupid...

- In the January 30, 2011 release I dropped the account/search page methods in favor of a "feeds" method. It uses around 10% of the bandwidth of the old method, is even more reliable (than what was already better than subscriptions), and is a few times as fast. I might later make the timestamp reader read hours/minutes for the ones who want to use this every day.

- Yes, I know the Multiple URLs Opener is stolen. Credit to techmilieu.com, but the site appears gone, lol.