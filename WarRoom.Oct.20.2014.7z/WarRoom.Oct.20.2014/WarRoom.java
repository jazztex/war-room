/**
 * Copyright 2014 FukkenSaved
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * How to contact FukkenSaved:
 * Youtube: https://www.youtube.com/channel/UCOD8oczNVUUt4rph05q4d2g
 * AIM: DarthTutu
 * MSN: seriousbusiness@yahoo.com
 */    

import java.util.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

/**
 * Rewrite of FukkenSaved's War Room removing unnecessary enumeration of URLs in
 * favor of merely listing what accounts have new videos.
 * Replaced account and search page methods with a superior feeds method.
 * @version Aug 24 2011
 * @author FukkenSaved
 */
public class WarRoom
{
	
	/* CONSTANTS */
	
	// Number of subscriptions in a Youtube page. Fuck them for lowering it.
	// This may eventually get put into a settings file, but as of now there
	// is only one setting to change and compiling is easy with JCreator 3.5
	public static final int SUBS_PAGE = 40;
	
	/* VARIABLES */
	
	/**
	 * The interface should be based here and all sub operations should have their
	 * own methods.
	 */
	public static void main(String[] args)
	{
		
		// Prevent sockets from flooding the TCP stack.
		System.setProperty("http.keepAlive", "false");
		System.setProperty("http.maxConnections", "3");
		
		// This is an infinite loop. Ideally, the program will stay in this
		// loop until the user explicitly tells the program to exit.
		while(true)
		{
			
			// Greeting and list of options
			StringBuffer opt = new StringBuffer();
			opt.append("Welcome to FukkenSaved's War Room.\n");
			opt.append("Enter the corresponding number for the following commands:\n");
			opt.append("1 - Dump all the friends or subs from a Youtube account\n");
			opt.append("2 - Compare and contrast lists\n");
			opt.append("3 - Scan a list of accounts for new videos\n");
			opt.append("4 - Eliminate duplicates from a list and lowercase it\n");
			opt.append("5 - Search for any mention of a string on a list of accounts\n");
			opt.append("Enter anything else to exit the program.\n");
			opt.append("What would you like to do?\n");
			
			// I would have put a switch statement here but I want all GUI
			// activity in the main method (save for debug info).
			String temp = JOptionPane.showInputDialog(opt);
			int temp2 = Integer.valueOf(temp);
			if(temp2 == 1) {
				String acct = JOptionPane.showInputDialog("What account?");
				String temp1 = JOptionPane.showInputDialog("0 - friends, 1 - subscriptions, 2 - subscribers");
				int opty = Integer.valueOf(temp1);
				String file = JOptionPane.showInputDialog("Save to what file?");
				hashToFile(getSubsFrom(acct, opty), file);
			}
			else if(temp2 == 2) {
				String a = JOptionPane.showInputDialog("What's the file name of the first list?");
				String b = JOptionPane.showInputDialog("What's the file name of the second list?");
				String file = JOptionPane.showInputDialog("Save differences to what file?");
				contrastLists(a, b, file);
			}
			else if(temp2 == 3) {
				String list = JOptionPane.showInputDialog("What's the file name of the subscriptions list?");
				String days = JOptionPane.showInputDialog("How many days ago do you want to search for new videos?");
				int seconds = Integer.valueOf(days);
				String file = JOptionPane.showInputDialog("Save info to what file?");
				System.out.println("Accounts file: " + list);
				System.out.println("Results file: " + file);
				System.out.println("Scan period: " + days + " days");
				spy(hashFromFile(list), file, seconds);
			}
			else if(temp2 == 4) { // Doesn't need a separate list. Load to hash then save to same file
				String file = JOptionPane.showInputDialog("What's the file name of the subscriptions list?");
				hashToFile(hashFromFile(file), file);
			}
			else if(temp2 == 5) {
				String list = JOptionPane.showInputDialog("What's the file name of the subscriptions list?");
				String temp4 = JOptionPane.showInputDialog("What string should be searched for?");
				String file = JOptionPane.showInputDialog("Save results to what file?");
				search(hashFromFile(list), temp4, file);
			}
			else System.exit(0);
			
		} 
		
	}
	
	/**
	 * Scan a list of accounts for a String in the account page. I'm going to 
	 * keep the reasons why this would be useful confidential for now.
	 */
	public static void search(HashSet<String> list, String s, String file)
	{
		
		// HashSet of accounts with the string present
		HashSet<String> present = new HashSet<String>();
		
		/* For every account... */
		for(String i : list)
		{
			
			try {
				
				System.out.println("Scanning account: " + i);
				
				// Load the page
				URL u = new URL("http://www.youtube.com/user/" + i);
				URLConnection h = u.openConnection();
				Scanner in = new Scanner(h.getInputStream());
				in.useDelimiter("");
				
				/* For every line... */
				while(in.hasNext())
				{
					String temp = in.nextLine();
					if(temp.contains(s)) { present.add(i); break; } // Refers to line while loop 
				}
				
			} catch(Exception e) { e.printStackTrace(); }
			
		}
		
		System.out.println("Total accounts scanned: " + list.size());
		System.out.println("Accounts with string present: " + present.size());
		
		// Finally, record all the accounts to the specified file
		hashToFile(present, file);
		
	}
	
	/**
	 * New method to find new videos based off the youtube feeds for accounts.
	 * Will combine the benefits of both the old methods with greatly increased
	 * speed and reduced bandwidth.
	 * Note that the threshold is in days rather than seconds now.
	 * A threshold of 0 means only show videos published today.
	 */
	public static void spy(HashSet<String> list, String file, int threshold)
	{
		
		// This is the list of accounts that have new videos
		HashSet<String> newVideos = new HashSet<String>();
		
		// This is the list of accounts with no videos (or suspended/closed)
		HashSet<String> zomgPedos = new HashSet<String>();
		
		// This is the date to compare to based on the threshold
		int too = 0 - threshold;
		GregorianCalendar tCal = new GregorianCalendar();
		tCal.add(GregorianCalendar.DAY_OF_YEAR, too);
		
		// For every account in the list...
		niggers: for(String i : list) {
			
			// Run in a while loop to restart the search in case of errors
			// This will be escaped on condition that the search is completed
			while(true)
			{
				
				System.out.println("Feed method: " + i);
				
				// This is a new method so idk what kind of exceptions will occur
				try {
					
					// Open connection to feed page
					URL u = new URL("http://gdata.youtube.com/feeds/api/users/" + i +
								   	 "/uploads?orderby=updated");
					URLConnection h = u.openConnection();
					
					// The default delimiter should be fine
					Scanner in = new Scanner(h.getInputStream());
					in.useDelimiter("");
					
					// Load the entire URL into a String
					StringBuffer tempy = new StringBuffer();
					while(in.hasNext()) tempy.append(in.next());
					String temp = tempy.toString();
					
					// Scan for errors - if there is one, throw an exception
					if(temp.contains("<errors>"))
						throw new Exception("Errors present in feed");
						
					// If </feed> is not there the url did not get downloaded completely
					// This "guaranteed delivery" is not a luxury we had before
					if(!temp.contains("</feed>"))
						throw new Exception("Url download incomplete");
					
					// Find presence of timestamp. If present, compare date
					// with threshold date
					int temp2 = temp.indexOf("<published>");
					
					// If it's there and within the threshold, add it to the "new videos" list
					if(temp2 != -1) {
						
						// Get associated date with latest video
						int year = Integer.valueOf(temp.substring(temp2 + 11, temp2 + 15));
						int month = Integer.valueOf(temp.substring(temp2 + 16, temp2 + 18));
						int day = Integer.valueOf(temp.substring(temp2 + 19, temp2 + 21));
						GregorianCalendar videoDate = new GregorianCalendar();
						// Seriously, fuck Java for starting months with 0!
						videoDate.set(year, month - 1, day);
						
						// Check if the video was made on or after the threshold
						// If that is the case add the account to the "new videos" list
						if(videoDate.compareTo(tCal) >= 0)
							newVideos.add(i);
							
					}
					// If there are no videos, add it to the "no videos" list
					else { zomgPedos.add(i); }
					
					// Destroy the socket
					// This is important if you don't like your connection cut off
					h.getInputStream().close();
					
					// Break out of while loop
					continue niggers;
						
				}
				// So far the exceptions I've gotten are:
				// 1. A 403 error, probably due to hammering
				// 2. too_many_recent_calls - purposefully thrown in case of
				//    <errors> tag. Hammering.
				// 3. Inability to connect. Perhaps hammering.
				// 4. </feed> not present, which means the download was incomplete
				// 5. A 400 error - this is when a /channel/ is loaded rather 
				//    than a username. I'll implement that once my list exceeds
				//    around 250, for now they're all bookmarked
				catch(Exception e) { 
					e.printStackTrace(); 
					System.out.println("Waiting 2 minutes");
					try { Thread.sleep(120000); } catch(Exception f) { f.printStackTrace(); }
					System.out.println("Trying again");
				}
					
			}
			
		}
		
		try
		{
			// Now the information gathered has to be written to a text file.
			PrintWriter out = new PrintWriter(file);
			
			// Write new videos
			// In addition, make it go to thumbnails sorted by upload date (if possible)
			out.println("New videos:");
			for(String i : newVideos) { out.println("http://www.youtube.com/user/" + i + "/videos"); }
			out.println();
			
			// Write video-less accounts
			out.println("Empty accounts:");
			for(String i : zomgPedos) { out.println("http://www.youtube.com/user/" + i); }
			
			// Close the file (important)
			out.close();
		}
		catch(Exception e) { e.printStackTrace(); }
		
	}
	
	/**
	 * Compare and contrast two text files of subscriptions. Show what is unique 
	 * to each in a third file.
	 */
	public static void contrastLists(String a, String b, String file)
	{
		try {
			
			// Get subscription lists from respective files
			HashSet<String> list1 = hashFromFile(a);
			HashSet<String> list2 = hashFromFile(b);
			
			// See which accounts are in both and delete from both.
			// 1. Find every element that appears in both 
			HashSet<String> inter = new HashSet<String>();
			for(String i : list1)
				for(String j : list2) { if(i.equals(j)) inter.add(i); }
				
			// 2. Delete the duplicate element from both lists
			for(String i : inter) {
				 if(list1.contains(i)) list1.remove(i);
				 if(list2.contains(i)) list2.remove(i);
			}
			
			// Output unique elements for each list in a text file
			PrintWriter out = new PrintWriter(file);
			out.println("Unique to " + a + ":");
			for(String i : list1) { out.println(i); }
			out.println();
			out.println("Unique to " + b + ":");
			for(String i : list2) { out.println(i); }
			out.println();
			out.println("Common to both:");
			for(String i : inter) { out.println(i); }
			out.close();
		}
		catch(Exception e) { e.printStackTrace(); System.exit(0); }
		
	}
	
	/**
	 * Write an HashSet of Strings to a text file.
	 */
	public static void hashToFile(HashSet<String> a, String b)
	{
		try {
			PrintWriter out = new PrintWriter(b);
			for(String i : a) { out.println(i); }
			out.close(); // Important step - makes the file get fukken saved
		} catch(Exception e) { e.printStackTrace(); System.exit(0); }
	}
	
	/**
	 * Load an HashSet of Strings from a text file.
	 * Lowercase it too to eliminate duplicates
	 */
	public static HashSet<String> hashFromFile(String b)
	{
		try {
			HashSet<String> returnMe = new HashSet<String>();
			Scanner in = new Scanner(new File(b)); in.useDelimiter("");
			while(in.hasNextLine()) { returnMe.add(in.nextLine().toLowerCase()); }
			return returnMe;
		} catch(Exception e) { e.printStackTrace(); System.exit(0); return null; }
	}
	
	/**
	 * Returns a HashSet of all the subscriptions from an account if the flag
	 * if false, if true the friends are returned.
	 * Let's also coerce it to lower case
	 */
	public static HashSet<String> getSubsFrom(String acct, int opt)
	{
		try {
			
			// Initialize subscriptions list
			HashSet<String> subsFrom = new HashSet<String>();
			
			// The Youtube URL to use as a base. Further pages will be checked.
			// Here is where friends/subscriptions is differentiated, otherwise
			// the code should work the same for either
			String s = null;
			
			if(opt == 0)
			{
				s = new String("http://www.youtube.com/profile?user=" + acct + "&view=friends");
			}
			else if(opt == 1)
			{
				s = new String("http://www.youtube.com/profile?user=" + acct + "&view=subscriptions");
			}
			else if(opt == 2)
			{
				s = new String("http://www.youtube.com/profile?user=" + acct + "&view=subscribers");
			}
			else System.out.println("Ruh Roh");
			
			// Continue to fill up the subscriptions list until a page is run
			// across where no subscriptions are added.
			boolean i = true; // i means keep searching
			int j = 0; // This is the subs page. 
			
			// Page by page at this level
			while(i)
			{

				// Set URL to use based on value of j
				URL u = new URL(s + "&start=" + SUBS_PAGE*j);
				
				// Load the page
				URLConnection h = u.openConnection();
				Scanner in = new Scanner(h.getInputStream());
				in.useDelimiter("");
				
				// Line by line (of url) at this level
				while(in.hasNextLine())
				{
					String temp = in.nextLine(); // Get next line
					
					// Presence of "send message" indicates revert to home page.
					// Stop looking when this is encountered - breaks while loop
					if(temp.contains("Send Message")) { i = false; break; }
					
					// If /user/ is detected, add what comes after it before
					// a quotation mark to the list.
					int userAt = temp.indexOf("/user/");
					if(userAt != -1) // -1 means it's not there
					{
						// Find the following quotation mark
						int quotsAt = temp.indexOf("\"", userAt + 1);
						
						// Assert quotes exist before trying to add
						if(quotsAt != -1)
						{
							// Try to add what's between them to the list.
							String addMe = temp.substring(userAt + 6, quotsAt);
							
							// Make sure it's not the source account, a duplicate or
							// some wierd thing that gets in there for some reason
							if(!addMe.equalsIgnoreCase(acct) && !addMe.contains("return false"))
							{ subsFrom.add(addMe.toLowerCase()); } // Lower case to prevent duplicates
						}
						
					}
				}
				
				System.out.println("Page " + j + " scanned");
				
				// Increment j so the next page will be used next time
				j++;
			}
			
			System.out.println("Total for " + acct + ":");
			System.out.println(subsFrom.size());
			
			return subsFrom;
			
		} catch(Exception e) { e.printStackTrace(); System.exit(0); return null; }
		
	}
	
}