--- Introduction ---

The original purpose of this program was to give us the ability to watch accounts for new videos without revealing to the rest of the world that we are doing so. The girls are not producing for pedos but rather the win was produced because the girls were not aware of us. Girls become aware of pedos because they are being sent sexual requests, magnified in impact when antis are present. When the girls cannot be made aware of us then the antis will flag the videos. It follows then that pedos should keep the list of girls being useful to them completely secret.

However, methods were innovated to drastically improve the efficiency of video sorting. All "jailbait" sites were not able to keep up with my technology, and they became useless to me. I already knew about almost all of the useful girls on the sites and their methods of posting were incredibly inefficient. They also often pose too much of a risk with illegal material and have rules designed to keep me out.

It was annoying to have to rewrite War Room in the face of the v3 API, but the end result was far better. War Room can now handle both "anonymous" channel IDs as well as legacy usernames. Instead of listing the channels with new videos, all the new URLs are listed for use with youtube-dl. In addition, a permanent record is kept of these URLs to completely eliminate duplication of effort. This I believe to be everything I wanted War Room to be, combining many good ideas I implemented in Keek Downloader.

--- How to run this program ---

You will need:
youtube-dl, or something else that can batch download Youtube URLs in 240p
mtn thumbnailer - You definitely need this. There is simply nothing else that does the job. Fuck you if you're a Macfag.
IrfanView, or something else that can sort through images quickly
Java Runtime Environment, but preferably the JDK
DownloadHelper or an equivalent. You want something that runs clientside to prevent people from tracking your girls.

the run.bat file will work if the JRE is installed correctly.

In the youtube-dl folder, you want text files stuff.txt and stuff2.txt . 

run.bat - youtube-dl --format 5 --proxy "" --batch-file stuff.txt
run2.bat - youtube-dl --format 5 --proxy "" --batch-file stuff2.txt

You will also need your own Google developer key as if too many people use mine then Google will lock it out at 50k downloads unless I pay them. At about 600 a day that is 18k a month for me alone. War Room is a serious program for serious pedophiles. It is possible to use a method that doesn't require any key (as youtube-dl does) but that will mean too much programming work on my end. If you can't handle the 20 hour learning curve then you should go back and whine about not being able to fuck kids like everyone else does. A job, disability benefits or a girlfriend, you are at the mercy of someone else to get, but for most everything else if you want results you have to work for it.

--- Preparing this program for use ---

First you will need to obtain a subscriptions list for the program to scan. This program used to have the ability to dump all of the subscriptions from a Youtube account, but they change things all of the time. It did work in 2011 and evacuated the 600 or so accounts from my old channel. In the v3 API adaptation I removed this functionality.

You will have to manually copy all of the subscriptions to a text file. However closing your account won't do any good. You will still show up on the girls' subscribers and all your other activity will still be there. Even if you unsubscribe one by one the girls will all be asking why. They take unsubscribing as an insult. The damage has already been done. Just private everything on the account and don't use it anymore.

--- List of file names ---

readme.txt - This file, instructions to use the program

(month)##.txt, e.g. may9.txt - A list of accounts along with the month and day they were last scanned. This used to be in a huge master.txt but resulted in large inefficiencies once the scan period became 40+ days. You must review the videos made since the prior scan, and if scans cover 40 days while it's been 40 days since the last scan that meant you must search 80 days at the end. Splitting up the usernames by scanned date mostly solved the problem, and maintaining a record of URLs eliminated it. The files should be no more than 50 kb for legacy usernames or 75 kb for anonymous "UC" usernames. That translates to about 3,000 accounts per file. The process cannot be interrupted once it is started (or else you'll have to do it all over again) so you need to keep the size under control. I currently have more than 10,000 accounts split up into these lists.

(month)##-uc.txt e.g. mar12-uc.txt - Similar to the prior text file, but this one is for anonymous usernames, the kind that start with UC. Keep the username types segregated because Youtube is prone to changing stuff (often for the worse) and the access methods are slightly different.

results-(month)##.txt - Results from the scan for new URLs. You want to copy the new results to incoming.txt (mentioned later) to scan with youtube-dl. Then, copy everything before the start of the zero-videos account section and put it in your "zero videos" folder. That is an optional way to keep track of accounts that deleted all their videos. I don't have time to do that, but you would contrast the new list with the old list.

add.txt - List of accounts that you want to do a complete scan for. The scan should be for a ridiculously high number of days, like 999999. Legacy and anonymous usernames can be combined, but they should be split up when the names are transferred to the dated text files, which should of course be done immediately after the URLs are obtained from those accounts.

api_key.txt - Your Google developer key.

Feel free to use whatever file names you want. However these names are used for the purpose of instruction in the following section. Note however as a means of convenience the (month)##.txt files should be kept in a "dates" subfolder.

--- Scanning accounts for new videos ---

The file name you want to scan is the one that it's been the longest since you scanned it. The number of days to scan is the amount of calendar days it has been since you scanned that, plus at least one. If you scanned things a different way only do the days plus one. If you used this program during the last scan though, the permanent record allows you to overlap, so this could be any number of days up to the first time you scanned it with War Room. I'd say three scans worth to make sure you get everything.

If pedos do not know about the girls there is very little risk of videos/accounts being removed so you don't usually need to get stuff within minutes of it coming out. A shorter scan period is better on paper, but realistically you should be scanning the list of accounts about every seven days. If you are able to search a shorter period it's time to find new accounts. The results should be saved to results-(month)##.txt . Any new girls you want to track should be added to the account list file for today, e.g. if today is October 20 then add them to oct20.txt .

After a few minutes depending on the amount of accounts you will have a finished results file. I used to check them all by opening them all in the browser using ByTubeD to get all the videos since the last scan date, then for a couple months up to May 2015 used ViBaFu which was quicker. But the v3 API forced me to rewrite things and since the URLs are unique and there wasn't anything out there (besides the ViBaFu developer version which I didn't want to figure out how to compile) I just enumerated the URLs, eliminating this middleman and dramatically improving the efficiency of the process.

0. Put all the new URLs in incoming.txt (I have that on the desktop). Periodically, put them in stuff.txt and stuff2.txt in the youtube-dl folder, keeping the file sizes roughly equal.

1. Run the run.bat and run2.bat batch files in tandem. Use pre-opened instances of the command prompt (With Command Prompt Here or an equivalent). Keep youtube-dl up to date. You will be running them about 3 hours a day. They stop a lot for various reasons, when they do, delete everything in stuff.txt or stuff2.txt respectively up to where it stopped. If it's deleted, delete the URL. If it's sign-in (age restricted or private), add it to wontgo.txt which you can use with the multiple URLs opener. If it stalled, delete the incomplete file (but not the URL from the test file). After that is done, type run.bat or run2.bat in the respective command prompts to get it running again. You can use a different amount of instances but I find two to be the best balance.

2. I have a "Youtube Progress" folder with "1 - Incoming", "2 - Cleared", "3 - Thumbnails", "4 - Quality", and "5 - Review" in it. When the 240p downloads are completed the videos are taken to folder 1. Also, there should be a thumbs5 shortcut that links to "C:\Program Files\mtn-200808a-win32\mtn.exe" -c 5 -s 10 -w 3000 as the target, or wherever you have mtn. It takes too much bandwidth to get everything in a higher resolution. If you find a way to use less bandwidth (read: get the DASH 144p videos thumbnailed with mtn) let me know.

3. The Incoming folder is where the videos are put to sort, 300 files at a time. You can do more or less, I find 300 to be the best balance. Move the videos there from youtube-dl (starting from the earliest date created). Then drag the folder onto the thumbs5 shortcut.

4. After mtn is done, cut all the "_s.jpg" files and paste them in folder 3. Move the videos to folder 2. In both cases from folder 1.

5. The Thumbnails folder is where the thumbnails go. Once these are obtained, scan through them with IrfanView, deleting those that are clearly not win. Once there are only possible wins left, go back to folder 2 and look through the videos, deleting anything without a matching thumbnail then previewing what's left. If the videos are not worth downloading then delete them and the corresponding thumbnail. At the end there should be the 240p videos with matching thumbnails, which are what you are going to want to get from Youtube from the greater of 720p or best quality available.

6. Thankfully, youtube-dl has the video URLs in the file name! Get the videos with something like DownloadHelper, 3 running at once with a max queue of 6. DH can't get everything, use clipconverter.cc when it can't. Isn't it great that you don't have to keep the username folders that ByTubeD made anymore?

7. The Quality section is pretty much just "m" folders from folder 2 that I have delayed downloading.

8. The Review section is downloaded high-quality videos that have yet to be decided whether to be kept.

There's also means for keeping which accounts went from some to no videos (and vice versa) but it's too chaotic now. Formerly the results would be renamed to oldresults.txt on every scan and that would be compared with the zero video accounts on the new results.txt . This is the list of girls that have quit (or got hacked :/ ) and the ones that have come back from the dead. From experience the ratio of raised dead to dying is around 2:5. This is key if you want to try to find girls or bring them back after their account is closed or they delete all their videos. You can always put the zero-video lists in the "Zero" subfolder in "dates" and figure it out yourself...

My girls make hundreds of videos a day so that is too bandwidth intensive anyway to download them all in 720p. 

--- Other notes ---

- If a girl's video title sounds important, i.e. they're quitting, you should listen. Also this can yield new accounts sometimes, and you should check the downbar whenever you're getting the girls' videos. Stay tuned, I might make something for instagram (or find a way to fuck 4kstogram).

- QuickJava is handy for a variety of reasons. The primary usefulness is being able to easily disable Java or Flash. Having the Add-on Bar for Firefox is a necessity, you'll need the Classic Theme Restorer.

- If you hold control and use the mouse wheel you can zoom in to get a better look at the thumbnails.

- 720p is the best compromise of video quality, size and cpu usage. 

- Sometimes DownloadHelper fails to get videos. Your Recycle Bin will have a "trail" to find out where these zero-byte videos came from, so you shouldn't empty it until you're find.

- The Multiple URLs Opener will not work properly with Torbutton unless you disable "Block Non-Tor access to network from file:// urls". But, you should be using the prepackaged Tor Browser anyway.

- Before adding any accounts search the Dates folder for anything containing that text. Maybe later I'll provide a method for finding duplicates across files. KeekDownloader has something, but I'd have it scan a subfolder. The permanent record will still eliminate the videos from being downloaded twice, but it's better to keep the footprint of this program as small as possible.

- I wouldn't recommend talking to the girls at all unless they are being ruined by asshats. The weapons at your disposal are to ask that they make backup/off-site accounts (as a defense against flagging), that they don't get naked or give out personal info (for their safety) and friends only their video comments, channel comments and PMs (when they are being harassed). But if they only talked to other kids their age we would rarely have to use these weapons.

- Feel free to get those fucktards that make sexual and fetish comments and requests to 12 year olds v&. They are the root cause of why we can't have nice things. This does not apply of course to skilled professionals that do not scare the girls away or invite antis or newfags that do. I am neutral towards this aspect of our culture. That aspect is also extremely rare.

- Don't view videos with an account. It will modify similar videos and recommendations based on your actions. As a result it will be girls you looked at in the past everyone knows about. It may also lead to people finding the girls you like.

- Girls seek each other out and they provide the best scouts for us. Search terms provide a base, but the #1 source is Youtube's recommendations from win videos.

- It is your judgement call on when it is time to share the videos. Sharing marks the girls as useful and invites idiots to groom the girls. A bad time is when they are ten years old and are recently very active. A good time is when they are sixteen years old. Either way you should edit out any references to the account name in the video and change the file name. And sharing the original video urls is pretty stupid...

- Yes, I know the Multiple URLs Opener is stolen. Credit to techmilieu.com, but the site appears gone, lol.