/**
 * Copyright 2015 FukkenSaved
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * How to contact FukkenSaved:
 * Youtube: https://www.youtube.com/channel/UCOD8oczNVUUt4rph05q4d2g
 * AIM: DarthTutu
 * I'm open to new chat services.
 */

/**
 * Yet another rewrite of War Room to implement the new version 3 API for
 * Youtube. In addition, the program will output a text file of URLs for use in
 * youtube-dl
 * @version May 21, 2015
 * @author FukkenSaved
 */
 
// The old exceptions I've found with the v2 API:
// 1. A 403 error, probably due to hammering
// 2. too_many_recent_calls - purposefully thrown in case of
//    <errors> tag. Hammering.
// 3. Inability to connect. Perhaps hammering.
// 4. </feed> not present, which means the download was incomplete
// 5. A 400 error - this is when a /channel/ is loaded rather 
//    than a username. I'll implement that once my list exceeds
//    around 250, for now they're all bookmarked


import java.util.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
 
public class WarRoom
{
	
	// Due to unique nature and access by spy method, make this static
	public static String api_key = "";
	
	// Let's make these static to avoid excessive parameters in methods
	static HashSet<String> newVideos; // List of new video URLs
	static HashSet<String> zomgPedos = new HashSet<String>(); // List of accounts with no videos (or suspended/closed)
	static HashSet<String> records; // This is the list of video IDs that we have already seen
	static GregorianCalendar tCal; // Threshold time - only add videos after this
	
	// This is the error log I used in Keek Downloader to mirror the console.
	public static PrintStream log;
	
	/**
	 * The interface should be based here and all sub operations should have
	 * their own methods.
	 */
	public static void main(String[] args)
	{
		
		// Prevent sockets from flooding the TCP stack.
		System.setProperty("http.keepAlive", "false");
		System.setProperty("http.maxConnections", "3");
		
		// Initialize error log
		try { log = new PrintStream(new File("log.txt")); }
		catch(Exception e) { System.out.println("Facepalm.jpg"); System.exit(0); }
		
		// Load API key from file
		try {
			Scanner in = new Scanner(new File("api_key.txt")); in.useDelimiter("");
			api_key = in.nextLine();
		} catch(Exception e) { logMe(traceToString(e)); System.exit(0); }
		
		logMe("API key: " + api_key);
		
		// This is an infinite loop. Ideally, the program will stay in this
		// loop until the user explicitly tells the program to exit.
		while(true)
		{
			
			// Greeting and list of options
			StringBuffer opt = new StringBuffer();
			opt.append("Welcome to FukkenSaved's War Room.\n");
			opt.append("Enter the corresponding number for the following commands:\n");
			opt.append("1 - Scan a list of accounts for new videos\n");
			opt.append("2 - Scan a folder of text files for duplicate entries, ignore case\n");
			opt.append("3 - Eliminate duplicate entries from a text file, case sensitive\n");
			opt.append("Enter anything else to exit the program.\n");
			opt.append("What would you like to do?\n");
			
			String temp = JOptionPane.showInputDialog(opt);
			int temp2 = Integer.valueOf(temp);
			
			if(temp2 == 1) {
				String list = JOptionPane.showInputDialog("What's the file name of the subscriptions list?");
				String temp3 = JOptionPane.showInputDialog("How many days ago do you want to search for new videos?");
				int days = Integer.valueOf(temp3);
				String file = JOptionPane.showInputDialog("Save URLs to what file?");
				logMe("Accounts file: " + list);
				logMe("URLs file: " + file);
				logMe("Scan period: " + days + " days");
				spy(hashFromFile(list), file, days);
			}
			else if(temp2 == 2) {
				logMe("Not implemented yet"); // xxx
			}
			else if(temp2 == 3) {
				// Simple enough: Just 
				String file = JOptionPane.showInputDialog("What's the file name?");
				hashToFile(hashFromFile(file), file);
				logMe(file + ": Duplicates removed, case sensitive");
			}
			else {
				log.close();
				System.exit(0);	
			}
			
		}
		
	}
	
	/**
	 * Will pass on a call to getURLs for every account in the account list.
	 */
	public static void spy(HashSet<String> list, String file, int threshold)
	{
		
		// This is the list of video IDs not viewed since threshold date
		newVideos = new HashSet<String>();
		
		// This is the list of accounts with no videos (or suspended/closed)
		zomgPedos = new HashSet<String>();
		
		// This is the list of video IDs that we have already seen
		records = hashFromFile("records.txt");
		
		// tCal is the date to compare to based on the threshold
		int too = 0 - threshold;
		tCal = new GregorianCalendar();
		tCal.add(GregorianCalendar.DAY_OF_YEAR, too);
		
		// For every account in the list...
		jews: for(String i : list) {
			
			// Run in a while loop to restart the search in case of errors
			// This will be escaped on condition that the search is completed
			
			while(true) {
				
				logMe("Scanning account: " + i);
				
				// Failure of this try block will restart the infinite loop
				try {
					
					/* Because Google is operated by homosexuals, they decided to
					   put the user's uploads in a playlist. We have to get that
					   playlist first. */
					   
					// Build URL for connection
					StringBuffer buf = new StringBuffer();
					buf.append("https://www.googleapis.com/youtube/v3/channels?part=contentDetails");
					
					// An "anonymous" ID starts with UC and has 24 characters
					// Different URLs for these IDs and legacy usernames
					if(i.length() == 24 && i.substring(0, 2).equals("UC"))
						buf.append("&id=" + i);
					else
						buf.append("&forUsername=" + i);
						
					// Finally, add my access key. Maybe make this editable per user
					buf.append("&key=" + api_key);
					
					String temp = gimmeURL(buf.toString());
					standardValidation(temp);
					
					// If no upload playlist is present, this is a closed channel (I hope)
					int loc = temp.indexOf("\"uploads\"");
					
					if(loc == -1) {
						logMe("Closed account. Moving to next one.");
						zomgPedos.add(i);
						continue jews;
					}
					
					String playlist = temp.substring(loc + 12, loc + 36);
					
					logMe("Playlist: " + playlist);
					
					/* Now that we have the playlist, we can dump the URLs for
					   the videos that have been made since the threshold date */
					
					// Pass this to a different method, as it needs to be restarted
					// by itself on failure
					getVideoURLs(playlist, "", i);
					
					// If it gets this far, the channel was successfully scanned.
					// Proceed to the next channel.
					continue jews;
					
				}
				
				catch(Exception e) {
					
					// First and foremost, print the exception
					logMe(traceToString(e));
					
					// Standard response is wait 2 minutes and try again
					logMe("Waiting 2 minutes");
					try { Thread.sleep(120000); } catch(Exception f) { logMe(traceToString(e)); }
					logMe("Trying again");
					
					// Then the infinite loop will reiterate
					
				}
				
			}
			
		}
		
		/* Now for the much simpler matter of recording the results to a text file */
		try
		{
			// Now the information gathered has to be written to a text file.
			PrintWriter out = new PrintWriter(file);
			
			// Write new videos
			// In addition, make it go to thumbnails sorted by upload date (if possible)
			out.println("New URLs:");
			for(String i : newVideos) { out.println("http://www.youtube.com/watch?v=" + i); }
			out.println();
			
			// Write video-less accounts
			out.println("Empty accounts:");
			for(String i : zomgPedos) { out.println("http://www.youtube.com/user/" + i); }
			
			// Close the file (important)
			out.close();
		}
		catch(Exception e) { logMe(traceToString(e)); }
		
		/* Finally, we need to update the central database. Any videos already
		 * present will not be added to the new video results. */
		try
		{
			// Have a prompt so that user can verify that results look fine before updating
			JOptionPane.showMessageDialog(null, "Scan completed. Press OK to update records.");
			
			// Load the existing records
			HashSet<String> updateMe = hashFromFile("records.txt");
			
			// Add the new video list to the records
			for(String i : newVideos) updateMe.add(i);
			
			// Overwrite the records file
			hashToFile(updateMe, "records.txt");
		}
		catch(Exception e) { logMe(traceToString(e)); }
		
	}
	
	/**
	 * Due to (mostly new) accounts exceeding the 50 limit, it is necessary to
	 * be able to scan multiple pages. When the limit is reached, this method
	 * calls itself using the nextPageToken hopefully parsed from the URL.
	 *
	 * Parameters: 
	 * Playlist ID
	 * nextPageToken (blank if first page)
	 * Name of channel - either a legacy or "anonymous" ID
	 *
	 * If the second parameter is blank, don't include the nextPageToken
	 */
	public static void getVideoURLs(String playlist, String currentToken, String accountName)
	{
		
		// Put this all in a while loop. On failure, it will keep trying again
		while(true) {
			
			try {
			
				// Create the long ass URL to get the feed
				StringBuffer buf = new StringBuffer();
				buf.append("https://www.googleapis.com/youtube/v3/playlistItems");
				buf.append("?part=snippet&maxResults=50");
				
				// If the second parameter is blank, don't include the nextPageToken
				if(currentToken != "") buf.append("&pageToken=" + currentToken);
				
				buf.append("&playlistId=" + playlist + "&key=" + api_key);
				
				logMe("URL: " + buf.toString());
				
				// Get the URL and convert the data to a String
				String temp = gimmeURL(buf.toString());
				standardValidation(temp);
				
				// First let's see the total results. If there are zero, then
				// add this account to the zero-videos list and continue the main loop
				int loc = temp.indexOf("\"totalResults\":");
				char total = temp.charAt(loc + 16);
				
				if(total == '0') {
					logMe("Account has zero videos");
					zomgPedos.add(accountName);
					return;
				}
				
				// Create a Scanner for the feed
				Scanner in = new Scanner(temp);
				
				// This is the counter of URLs added
				int urls = 0;
				
				// This is the next page token
				String futureToken = "";
				
				// Scan every line obtained from the URL and respond accordingly
				while(in.hasNextLine()) {
					
					String next = in.nextLine();
					
					// Account for next page token
					if(next.contains("\"nextPageToken\":")) {
						
						// Unfortunately, this does not behave in so predictable a fashion
						// as the number of characters is not fixed.
						
						// This is where the token begins
						int loc1a = next.indexOf("\"nextPageToken\":") + 18;
						
						// This is where the token ends
						int loc1b = next.indexOf("\"", loc1a + 1);
												
						// We'll see errors if next page tokens are different than 6 characters
						futureToken = next.substring(loc1a, loc1b);
						logMe("Next page token: " + futureToken);
						
					}
					
					// Account for publish date
					if(next.contains("\"publishedAt\":")) {
						
						int loc2 = next.indexOf("\"publishedAt\":");
						
						int year = Integer.valueOf(next.substring(loc2 + 16, loc2 + 20));
						int month = Integer.valueOf(next.substring(loc2 + 21, loc2 + 23));
						int day = Integer.valueOf(next.substring(loc2 + 24, loc2 + 26));
						
						// Seriously, fuck Java for starting months with 0!
						GregorianCalendar videoDate = new GregorianCalendar();	
						videoDate.set(year, month - 1, day);
						
						// Date is further back than threshold. Move to the
						// next account.
						if(videoDate.compareTo(tCal) < 0) {
							logMe("Threshold reached.");
							return;
						}
						
					}
					
					// Account for video ID
					if(next.contains("\"videoId\":")) {
						
						int loc3 = next.indexOf("\"videoId\":");
						
						// We'll see errors if video IDs are different than 11 characters
						String addMe = next.substring(loc3 + 12, loc3 + 23);
						
						// Add the video ID to new videos list if not in records
						if(!records.contains(addMe)) {
							logMe("Adding video ID: " + addMe);
							newVideos.add(addMe);
						}
						else {
							logMe("Already in records: " + addMe);
						}
						
						// In either case we want to increment the urls counter
						urls++;

						// Call self if 50 videos limit exceeded
						if(urls >= 50) {
							logMe("50 video limit exeeded. Getting next page.");
							getVideoURLs(playlist, futureToken, accountName);
							return;
						}
						
					}
					
				}
				
				// It would get here if all the videos were within the threshold. The
				// method would otherwise return if a video beyond the limit were found.
				logMe("End of list; all videos were within threshold.");
			
				// If the program makes it here, hopefully the success condition has been met
				return;
			
			}
			
			catch(Exception e) {
				
				// First and foremost, print the exception
				logMe(traceToString(e));
				
				// Standard response is wait 2 minutes and try again
				logMe("Waiting 2 minutes");
				try { Thread.sleep(120000); } catch(Exception f) { logMe(traceToString(e)); }
				logMe("Trying again");
				
				// Then the infinite loop will reiterate
				
			}
			
		}
		
	}
	
	/**
	 * Perform a series of tests intended to give assurance that the complete
	 * file has been downloaded.
	 */	
	public static void standardValidation(String v) throws Exception
	{
		
		// Equivalent (I hope) of <errors> tag in v2
		if(v.contains("\"error\":"))
			throw new Exception("Errors present in feed");
		
		// The new validation for end of file is a single right bracket.
		Scanner in = new Scanner(v);
		
		while(in.hasNextLine()) {
			String x = in.nextLine();
			if(x.equals("}")) return;
		}
		
		throw new Exception("No line with only a right bracket signaling EOF");
		
	}
		
	/**
	 * Return a String representation of the data received from a URL.
	 */
	public static String gimmeURL(String url) throws Exception
	{
		
		// Open the connection
		URL u = new URL(url);
		URLConnection h = u.openConnection();
		
		// The default delimiter should be fine
		Scanner in = new Scanner(h.getInputStream());
		in.useDelimiter("");
		
		// Load the entire URL into a String
		StringBuffer tempy = new StringBuffer();
		while(in.hasNext()) tempy.append(in.next());
		String temp = tempy.toString();
		
		// Destroy the socket to prevent flooding of TCP stack
		h.getInputStream().close();
		
		return temp;
	}
	
	/**
	 * Write an HashSet of Strings to a text file.
	 */
	public static void hashToFile(HashSet<String> a, String b)
	{
		try {
			PrintWriter out = new PrintWriter(b);
			for(String i : a) { out.println(i); }
			out.close(); // Important step - makes the file get fukken saved
		} catch(Exception e) { logMe(traceToString(e)); System.exit(0); }
	}
	
	/**
	 * Load an HashSet of Strings from a text file.
	 * Don't lowercase it - "anonymous" IDs and video IDs are case sensitive.
	 */
	public static HashSet<String> hashFromFile(String b)
	{
		try {
			HashSet<String> returnMe = new HashSet<String>();
			Scanner in = new Scanner(new File(b)); in.useDelimiter("");
			while(in.hasNextLine()) { returnMe.add(in.nextLine()); }
			return returnMe;
		} catch(Exception e) { logMe(traceToString(e)); System.exit(0); return null; }
	}
	
	/**
	 * Report progress to both errors.txt and the console.
	 */
	public static void logMe(String a)
	{
		System.out.println(a);
		log.println(a);
	}
	
	/** 
	 * Return a String of a stack trace for an exception.
	 */
	public static String traceToString(Exception e)
	{
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
}